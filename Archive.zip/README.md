# CanvasAPI

Canvas API is the API that serves the Canvas mobile and web apps. It will coordinate all backend logic through an AWS Gateway.

## Getting started

This is an AWS Lambda Function

- To deploy run npm install, zip up the root folder and add to the Lambda Function
- Ensure your routes are also in an AWS Gatway and deployed
