const AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-2" });
const utils = require("../utils/buildResponse");
const bcrypt = require("bcryptjs");
const { login } = require("./login");
const { createAccount } = require("../account/createAccount");

const dynamoDB = new AWS.DynamoDB.DocumentClient();
let userTable = "CanvasUsers";

async function register(userInfo) {
  const firstName = userInfo.firstName;
  const lastName = userInfo.lastName;
  const email = userInfo.email;
  const username = userInfo.username;
  const password = userInfo.password;

  if (
    !username ||
    !password ||
    !email ||
    !password ||
    !firstName ||
    !lastName ||
    !userTable
  ) {
    return utils.buildResponse(401, {
      message: "All fields are required",
    });
  }

  const dynamoUser = await getUser(username);
  if (dynamoUser && dynamoUser.username) {
    return utils.buildResponse(401, {
      message: "Username already exists. Please choose another one.",
    });
  }

  const encryptedPW = bcrypt.hashSync(password.trim(), 10);
  const user = {
    firstName: firstName,
    lastName: lastName,
    email: email,
    username: username.toLowerCase().trim(),
    password: encryptedPW,
  };

  const savedUserResponse = await saveUser(user);
  if (!savedUserResponse) {
    return utils.buildResponse(503, {
      message: "Server Error. Please try again later.",
    });
  }

  var result = await createAccount(
    { username },
    { email, firstName, lastName }
  );

  if (result.statusCode !== 201) {
    return utils.buildResponse(503, {
      message: "Error creating user account. Please try again later.",
    });
  }

  const loginRequest = {
    username: user.username,
    password: userInfo.password,
    table: userTable,
  };

  return await login(loginRequest);
}

async function getUser(username) {
  const params = {
    TableName: userTable,
    Key: {
      username: username,
    },
  };

  return await dynamoDB
    .get(params)
    .promise()
    .then(
      (response) => {
        return response.Item;
      },
      (error) => {
        console.error("There is an error getting the user:", error);
      }
    );
}

async function saveUser(user) {
  const params = {
    TableName: userTable,
    Item: user,
  };
  return await dynamoDB
    .put(params)
    .promise()
    .then(
      () => {
        return true;
      },
      (error) => {
        console.error("There is an error saving the user:", error);
      }
    );
}

module.exports.register = register;
