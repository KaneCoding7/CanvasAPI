const utils = require("./utils/buildResponse");

const healthPath = "/health";
const userAccount = "/userAccount";

exports.handler = async (event) => {
  console.log("Requested Event:", event);

  switch (true) {
    case evaluatePath(event, "GET", healthPath):
      return utils.buildResponse(200);
    case evaluatePath(event, "GET", userAccount):
      return utils.buildResponse(200);
  }

  return buildResponse(404, "Not Found");
};

function evaluatePath(event, medthod, path) {
  return event.path === path && event.httpMethod === medthod;
}
